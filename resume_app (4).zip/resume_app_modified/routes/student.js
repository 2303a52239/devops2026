const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const User = require('../models/User');
const Resume = require('../models/Resume');
const Project = require('../models/Project');

// Auth middleware
const isStudent = (req, res, next) => {
  if (!req.session.userId || req.session.role !== 'student')
    return res.status(401).json({ success: false, message: 'Unauthorized' });
  next();
};

// Multer setup for resume PDF
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, '../uploads/resumes');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    cb(null, `resume_${req.session.userId}_${Date.now()}${path.extname(file.originalname)}`);
  }
});
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') cb(null, true);
    else cb(new Error('Only PDF files allowed'));
  },
  limits: { fileSize: 5 * 1024 * 1024 }
});

// Get student dashboard data
router.get('/dashboard', isStudent, async (req, res) => {
  try {
    const user = await User.findById(req.session.userId).select('-password');
    const resume = await Resume.findOne({ userId: req.session.userId });
    const projects = await Project.find({ userId: req.session.userId }).sort({ createdAt: -1 });
    res.json({ success: true, user, resume, projects });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

// Save/Update resume details
router.post('/resume', isStudent, async (req, res) => {
  try {
    const { phone, dob, address, linkedin, github, portfolio,
            degree, branch, college, graduationYear, cgpa,
            skills, experience, certifications } = req.body;

    // Save DOB to User model
    if (dob) {
      await User.findByIdAndUpdate(req.session.userId, { dob: new Date(dob) });
    }

    let resume = await Resume.findOne({ userId: req.session.userId });
    const data = {
      phone, address, linkedin, github, portfolio,
      degree, branch, college, graduationYear, cgpa,
      skills: Array.isArray(skills) ? skills : (skills ? skills.split(',').map(s => s.trim()) : []),
      experience: experience || [],
      certifications: certifications || [],
      updatedAt: new Date()
    };

    if (resume) {
      Object.assign(resume, data);
      await resume.save();
    } else {
      resume = await Resume.create({ userId: req.session.userId, ...data });
    }

    // Return updated user with dob
    const user = await User.findById(req.session.userId).select('-password');
    res.json({ success: true, message: 'Resume details saved!', resume, user });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

// Parse resume PDF with AI (server-side proxy to avoid CORS)
router.post('/resume/parse', isStudent, async (req, res) => {
  try {
    const { pdfText } = req.body;
    if (!pdfText || pdfText.trim().length < 30) {
      return res.json({ success: false, message: 'PDF text is too short or empty' });
    }

    const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
    if (!ANTHROPIC_API_KEY) {
      return res.json({ success: false, message: 'ANTHROPIC_API_KEY not set in .env' });
    }

    const apiRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 1500,
        system: `You are a resume parser. Extract information from resume text and return ONLY a valid JSON object with no extra text, no markdown, no backticks. Use exactly these keys (leave as empty string "" if not found):
{
  "phone": "",
  "linkedin": "",
  "github": "",
  "portfolio": "",
  "degree": "",
  "branch": "",
  "college": "",
  "graduationYear": "",
  "cgpa": "",
  "skills": [],
  "experience": [{"company":"","role":"","duration":"","description":""}],
  "certifications": [{"name":"","issuer":"","year":""}]
}
Return ONLY the JSON object, nothing else.`,
        messages: [{ role: 'user', content: `Parse this resume:\n\n${pdfText.substring(0, 6000)}` }]
      })
    });

    if (!apiRes.ok) {
      const errText = await apiRes.text();
      return res.json({ success: false, message: `Anthropic API error: ${apiRes.status} - ${errText}` });
    }

    const apiData = await apiRes.json();
    const rawText = apiData.content?.[0]?.text || '';

    let parsed;
    try {
      const cleaned = rawText.replace(/```json|```/g, '').trim();
      parsed = JSON.parse(cleaned);
    } catch (e) {
      return res.json({ success: false, message: 'Could not parse AI response as JSON' });
    }

    res.json({ success: true, data: parsed });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

// Upload resume PDF
router.post('/resume/upload', isStudent, upload.single('resumeFile'), async (req, res) => {
  try {
    if (!req.file) return res.json({ success: false, message: 'No file uploaded' });

    let resume = await Resume.findOne({ userId: req.session.userId });
    if (resume) {
      resume.resumeFile = req.file.filename;
      resume.resumeFileName = req.file.originalname;
      await resume.save();
    } else {
      resume = await Resume.create({
        userId: req.session.userId,
        resumeFile: req.file.filename,
        resumeFileName: req.file.originalname
      });
    }

    res.json({ success: true, message: 'Resume uploaded!', filename: req.file.filename, originalName: req.file.originalname });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

// Add project
router.post('/project', isStudent, async (req, res) => {
  try {
    const { title, description, techStack, githubLink, liveLink } = req.body;
    const project = await Project.create({
      userId: req.session.userId,
      title,
      description,
      techStack: Array.isArray(techStack) ? techStack : (techStack ? techStack.split(',').map(s => s.trim()) : []),
      githubLink,
      liveLink
    });
    res.json({ success: true, message: 'Project added!', project });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

// Update project
router.put('/project/:id', isStudent, async (req, res) => {
  try {
    const { title, description, techStack, githubLink, liveLink } = req.body;
    const project = await Project.findOneAndUpdate(
      { _id: req.params.id, userId: req.session.userId },
      {
        title, description, githubLink, liveLink,
        techStack: Array.isArray(techStack) ? techStack : (techStack ? techStack.split(',').map(s => s.trim()) : [])
      },
      { new: true }
    );
    if (!project) return res.json({ success: false, message: 'Project not found' });
    res.json({ success: true, message: 'Project updated!', project });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

// Delete project
router.delete('/project/:id', isStudent, async (req, res) => {
  try {
    await Project.findOneAndDelete({ _id: req.params.id, userId: req.session.userId });
    res.json({ success: true, message: 'Project deleted!' });
  } catch (err) {
    res.json({ success: false, message: err.message });
  }
});

module.exports = router;
